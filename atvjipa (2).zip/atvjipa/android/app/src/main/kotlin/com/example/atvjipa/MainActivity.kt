package com.example.atvjipa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
